<?php require('head.php') ?>
<?php require('nav.php') ?>
<?php require('banner.php') ?>

  <main>
    <div class="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
      <p>Souhaitez-vous nous contacter ?</p>
    </div>
  </main>
  <?php require('footer.php') ?>
