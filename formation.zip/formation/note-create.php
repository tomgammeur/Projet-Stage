<?php

$heading = "Create Note";

if ($_SERVER['REQUEST_METHOD']=== 'POST'){
$sql->query('INSERT INTO notes(body, user_id) VALUES(:body, :user_id)',[
    //'body' => $_POST{'body'}    
]);
}
require "note-create.view.php";