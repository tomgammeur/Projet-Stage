<?php
require 'functions.php';

require 'routes.php';